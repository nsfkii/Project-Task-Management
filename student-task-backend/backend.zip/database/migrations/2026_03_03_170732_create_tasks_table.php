<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('tasks', function (Blueprint $table) {
        $table->id();
        // foreign key yang terhubung ke id di tabel users
        $table->foreignId('user_id')->constrained()->onDelete('cascade'); 
        
        $table->string('title');
        $table->string('subject');
        $table->text('description')->nullable();
        $table->date('deadline');
        $table->enum('priority', ['low', 'medium', 'high']);
        $table->enum('status', ['pending', 'progress', 'done'])->default('pending');
        $table->timestamps();
    });
}
};
